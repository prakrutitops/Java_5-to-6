package com.tops;

import java.util.List;

import javax.persistence.*;


import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.ValueGenerationType;

@Entity
@Table(name="question12")
public class Question 
{
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name="question_id")
	int id;
	
	@Column(name="question_name")
	String qname;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQname() {
		return qname;
	}

	public void setQname(String qname) {
		this.qname = qname;
	}
	
	@ManyToMany(targetEntity = Answer.class, cascade = { CascadeType.ALL })
	
	@JoinTable(name = "questin_answer", joinColumns = { @JoinColumn(name = "q_id") }, inverseJoinColumns = { @JoinColumn(name = "ans_id") })
	
	
	List<Answer>list;

	public List<Answer> getList() {
		return list;
	}

	public void setList(List<Answer> list) {
		this.list = list;
	}
	
	
}

package com.dao;

public class Mydao 
{

}

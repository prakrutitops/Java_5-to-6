package com.controller;

import java.util.ArrayList;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.connect.Util;
import com.model.Address;
import com.model.Person;

public class MainClass 
{
	public static void main(String[] args) 
	{
		
		Session sess =  new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter Your Name");
		String name = sc.next();
		
		System.out.println("Enter Your Name2");
		String name2 = sc.next();
		
		System.out.println("Enter Your Address");
		String address = sc.next();
		
		Person p =new Person();
		Person p2 =new Person();
		p.setPname(name);
		p2.setPname(name2);
		
		ArrayList<Person> arrayList = new ArrayList<>();
		arrayList.add(p);
		arrayList.add(p2);
		
		Address a =new Address();
		a.setAddress(address);
		
		a.setPerson(arrayList);
		
		sess.save(p);
		sess.save(p2);
		sess.save(a);
		tr.commit();
		sess.close();
		
	}
}

package com.controller;

import java.util.ArrayList;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.connect.Util;
import com.model.Address;
import com.model.Person;

public class MainClass 
{
	public static void main(String[] args) 
	{
		
		Session sess =  new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter Your Name");
		String name = sc.next();
		
		System.out.println("Enter Your Address");
		String address = sc.next();
		
		System.out.println("Enter Your Address 2");
		String address2 = sc.next();
		
		Person p =new Person();
		p.setPname(name);
		
		Address a =new Address();
		a.setAddress(address);
		
		Address a2 =new Address();
		a2.setAddress(address2);
		
		ArrayList<Address> arrayList = new ArrayList<>();
		arrayList.add(a);
		arrayList.add(a2);
		
		p.setAdd(arrayList);
		
		sess.save(p);
		sess.save(a2);
		sess.save(a);
		tr.commit();
		sess.close();
		
	}
}
